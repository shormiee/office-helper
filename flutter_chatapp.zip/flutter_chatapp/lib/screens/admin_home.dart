import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_chatapp/notifications/pushNotificationService.dart';
import 'package:flutter_chatapp/screens/auth-screen.dart';
import 'package:flutter/material.dart';
import 'package:flutter_chatapp/widgets/requests.dart';
import 'package:cloud_firestore/cloud_firestore.dart';




class  OfficeHelper extends StatefulWidget {
  @override
  State< OfficeHelper> createState() => _OfficeHelperState();
}

class _OfficeHelperState extends State<OfficeHelper> {


  // getToken => call this function
  // in getToekn function update the token
  final firebaseMessaging = FirebaseMessaging.instance;
  @override
  void initState() {
    super.initState();
    Future.delayed(Duration.zero, () {
      this.firebaseCloudMessagingListeners(context);
    }
    );
  }

  void firebaseCloudMessagingListeners(BuildContext context) {
    _firebaseMessaging.getToken().then((deviceToken) {
      print("Firebase Device token: $deviceToken");

    });
  }


  final user = FirebaseAuth.instance.currentUser;
  Future initialize(context) async{
    {
      FirebaseMessaging.onMessage.listen((request) {
        if(request.notification != null) {
          print(request.notification.body);
          print(request.notification.title);
        }
      });
      FirebaseMessaging.onMessageOpenedApp.listen((request) {
        final routeFromMessage = request.data['route'];
        print(routeFromMessage);
      });
      // FirebaseMessaging.onBackgroundMessage((RemoteMessage message) => null);
      FirebaseMessaging.onMessage.listen((RemoteMessage request) {
        print('Message in the foreground!');
        print('Message data: ${request.data}');
      });
      firebaseMessaging.subscribeToTopic('request');
    }

    }

  }

  //



//   final FirebaseMessaging _firebaseMessaging = FirebaseMessaging.instance;
//   _firebaseMessaging.configure(
//   onLaunch: (Map<String, dynamic> message) {
//   print('onLaunch called');
//   },
//   onResume: (Map<String, dynamic> message) {
//   print('onResume called');
//   },
//   onMessage: (Map<String, dynamic> message) {
//   print('onMessage called');
//   },
//   );
//   _firebaseMessaging.subscribeToTopic('all');
//   _firebaseMessaging.requestNotificationPermissions(IosNotificationSettings(
//   sound: true,
//   badge: true,
//   alert: true,
//   ));
//   _firebaseMessaging.onIosSettingsRegistered
//       .listen((IosNotificationSettings settings) {
//   print('Hello');
//   });
//   _firebaseMessaging.getToken().then((token) {
//   print(token); // Print the Token in Console
//   });
// }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text('office helpers screen'),
        actions: [
          DropdownButton(icon: Icon(Icons.more_vert,
            color: Theme.of(context).primaryIconTheme.color,

          ),
            items: [
              DropdownMenuItem(child: Container(child: Row(
                children: [
                  Icon(
                      Icons.exit_to_app
                  ),
                  SizedBox(width: 8,),
                  Text('Logout'),
                ],
              ),
              ),
                value: 'logout',
              )
            ],
            onChanged: (itemIdentifier) {
              if (itemIdentifier == 'logout') {
                AuthHelper.logOut();
              }
            },
          ),
        ],
      ),
      body: Container(
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
         reverse: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,

            children: <Widget>[
             Container(
                 height: 520,
                 color: Colors.white,
                 child: Column(
                   mainAxisSize: MainAxisSize.min,
                   children: [
                     Requests(),
                   ],
                 )),

            ],

          ),

        ),
      ),
    );
  }
}