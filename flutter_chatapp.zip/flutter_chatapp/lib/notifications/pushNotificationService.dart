import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter/material.dart';

import 'dart:io';
import 'package:flutter/material.dart';

class PushNotificationService {
  final firebaseMessaging = FirebaseMessaging.instance;
  Future initialize(context) async
  {
    FirebaseMessaging.onMessage.listen((request) {
      if(request.notification != null) {
        print(request.notification.body);
        print(request.notification.title);
      }
    });
    FirebaseMessaging.onMessageOpenedApp.listen((request) {
       final routeFromMessage = request.data['route'];
       print(routeFromMessage);
    });
    // FirebaseMessaging.onBackgroundMessage((RemoteMessage message) => null);
      FirebaseMessaging.onMessage.listen((RemoteMessage request) {
        print('Message in the foreground!');
        print('Message data: ${request.data}');
      });
    firebaseMessaging.subscribeToTopic('request');
  }
}
// Future<String> getToken() async {
//     String token = await firebaseMessaging.getToken();
//
// }