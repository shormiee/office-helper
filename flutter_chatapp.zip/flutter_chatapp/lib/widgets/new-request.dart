// import 'dart:convert';
// import 'dart:io';


import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';


class NewRequest extends StatefulWidget {


  @override
  _NewRequestState createState() => _NewRequestState();
}
class _NewRequestState extends State<NewRequest> {
  final user = FirebaseAuth.instance.currentUser;
  var _selectedRequest = '';

void _sendRequest() async {
final user = FirebaseAuth.instance.currentUser;
final userData =  await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
final newRequest= await FirebaseFirestore.instance.collection('request').add({
    'text': _selectedRequest,
    'userId': user.uid,
    "created_at": Timestamp.now(),
    'name': userData['name'],
     "isAccped":false,
    "assignedTo":""
  });
// we have new request. we have its id
//

  final result=await FirebaseFirestore.instance.collection('users').where('role',isEqualTo: 'user').get();
  for(var item in result.docs ){
    sendRequestnotifciation(newRequest.id,item.data()['token']);
  }
}
sendRequestnotifciation( String requestId,String userToken) async {
  // send notification
  Map<String, String> headerMap = {
    'Content-Type': 'application/json',
    'Authorization': 'key=$serverToken'
  };
  var req =
      Provider.of<AppData>(context, listen: false).req;
  Map bodyMap = {
    "notification": {
      "body": snapshot.data().text,
      "title": "New  Request."
    },
    "priority": "high",
    "data": {
      "clickaction": "FLUTTERNOTIFICATIONCLICK",
      "id": "1",
      "status": "done",
      "ride_id": ride_request_id
    },
    "to": token
  };
  var response = await http.post(
      Uri.parse('https://fcm.googleapis.com/fcm/send'),
      headers: headerMap,
      body: jsonEncode(bodyMap));


}
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              ElevatedButton(
                  child: const Text('coffee'),
                onPressed: (
                    ) {
                    //print(data.docs[0]['text']);
                   _selectedRequest = 'Coffee';
                  }

                  ),
             SizedBox(
               width: 30,
                ),
              ElevatedButton(
                child: const Text('water'),
                onPressed: () {
                    _selectedRequest = 'Water';
                },
              ),
              SizedBox(
                width: 30,
              ),
              ElevatedButton(
                child: const Text('tea'),
                onPressed: () {
                  _selectedRequest = 'tea';
                },
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80,
                height: 60,
                // decoration: BoxDecoration(
                //  color: Colors.red,
                // ),
                child: ElevatedButton(

                 child: Text('done'),

                  onPressed: () {
                  setState(() {
                     // ignore: unnecessary_statements
                    // if( _selectedRequest == '') {
                    //   Text('select a request');
                    // }
                    // else {
                    //   _sendRequest();
                    // }
                    // sendNotification(tokenId, _selectedRequest, "you have a request");
                    // ignore: unnecessary_statements
                    _selectedRequest.isEmpty ? null : _sendRequest();
                   // _selectedRequest = '';
                  },

                  );
                },

                ),

                  // onRefresh: () {
                  //   // implement later
                  //   return;
                  // }
              ),
            ],
          ),
        ],
      ),
    );
  }


}
// class PushNotificationService {
//   static final _notifications = FlutterLocalNotificationsPlugin();
//   static Future _notificationsDetails() async {
//     return NotificationDetails(
//       android:AndroidNotificationDetails(
//         'channel id',
//         'channel name',
//         importance: Importance.max,
//       ),
//       iOS: IOSNotificationDetails(),
//     );
//   }
//
//   static Future showNotification (
//       {
//         int uid = 0,
//         String title,
//         String body,
//         String payload,
//       })
//   async => _notifications.show(uid, title, body,await _notificationsDetails(),
//     payload: payload,
//
//   );}
